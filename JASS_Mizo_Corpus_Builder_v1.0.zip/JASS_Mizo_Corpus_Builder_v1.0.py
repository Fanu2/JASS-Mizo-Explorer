import sys
import sqlite3
import hashlib
from pathlib import Path
from datetime import datetime, timezone

from PySide6.QtCore import QObject, QThread, Signal, Slot
from PySide6.QtWidgets import (
    QApplication, QFileDialog, QGridLayout, QGroupBox, QHBoxLayout,
    QLabel, QMainWindow, QMessageBox, QProgressBar, QPushButton,
    QPlainTextEdit, QVBoxLayout, QWidget
)

BATCH_SIZE = 5000


def sha256_file(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        while True:
            block = f.read(1024 * 1024)
            if not block:
                break
            h.update(block)
    return h.hexdigest()


class BuildWorker(QObject):
    progress = Signal(int)
    status = Signal(str)
    finished = Signal(dict)
    failed = Signal(str)

    @Slot(str, str)
    def run(self, source_name, db_name):
        try:
            source = Path(source_name)
            db_path = Path(db_name)

            if db_path.exists():
                raise RuntimeError(
                    f"Output database already exists:\n{db_path}\n\n"
                    "Choose a new output filename. The builder never overwrites an existing database."
                )

            self.status.emit("Calculating source SHA-256…")
            source_hash = sha256_file(source)
            size = source.stat().st_size

            # Count bytes while importing to provide progress without loading the file.
            conn = sqlite3.connect(str(db_path))
            try:
                conn.execute("PRAGMA journal_mode=WAL")
                conn.execute("PRAGMA synchronous=NORMAL")
                conn.execute("PRAGMA temp_store=MEMORY")
                conn.execute("PRAGMA foreign_keys=ON")

                conn.executescript("""
                CREATE TABLE corpus (
                    id INTEGER PRIMARY KEY CHECK (id = 1),
                    source_file TEXT NOT NULL,
                    source_sha256 TEXT NOT NULL,
                    source_size_bytes INTEGER NOT NULL,
                    record_count INTEGER NOT NULL,
                    created_at TEXT NOT NULL
                );

                CREATE TABLE records (
                    id INTEGER PRIMARY KEY,
                    source_line INTEGER NOT NULL UNIQUE,
                    text TEXT NOT NULL,
                    character_count INTEGER NOT NULL,
                    word_count INTEGER NOT NULL
                );

                CREATE INDEX idx_records_source_line ON records(source_line);

                CREATE VIRTUAL TABLE records_fts USING fts5(
                    text,
                    content='records',
                    content_rowid='id'
                );
                """)

                total = 0
                total_chars = 0
                total_words = 0
                batch = []
                scanned_bytes = 0

                self.status.emit("Importing records…")

                with source.open("r", encoding="utf-8", errors="strict", newline="") as f:
                    for line_no, raw in enumerate(f, 1):
                        scanned_bytes += len(raw.encode("utf-8"))
                        text = raw.rstrip("\r\n")
                        words = text.split()
                        chars = len(text)
                        wc = len(words)

                        batch.append((line_no, text, chars, wc))
                        total += 1
                        total_chars += chars
                        total_words += wc

                        if len(batch) >= BATCH_SIZE:
                            conn.executemany(
                                "INSERT INTO records(source_line,text,character_count,word_count) VALUES(?,?,?,?)",
                                batch,
                            )
                            conn.commit()
                            batch.clear()

                        if total % 10000 == 0:
                            pct = min(98, int(scanned_bytes / max(size, 1) * 100))
                            self.progress.emit(pct)
                            self.status.emit(f"Imported {total:,} records…")

                if batch:
                    conn.executemany(
                        "INSERT INTO records(source_line,text,character_count,word_count) VALUES(?,?,?,?)",
                        batch,
                    )
                    conn.commit()

                self.status.emit("Building full-text search index…")
                conn.execute(
                    "INSERT INTO records_fts(rowid,text) SELECT id,text FROM records"
                )
                conn.commit()

                created = datetime.now(timezone.utc).isoformat()
                conn.execute(
                    """INSERT INTO corpus
                       (id,source_file,source_sha256,source_size_bytes,record_count,created_at)
                       VALUES(1,?,?,?,?,?)""",
                    (source.name, source_hash, size, total, created),
                )
                conn.commit()

                self.status.emit("Running verification…")
                db_count = conn.execute("SELECT COUNT(*) FROM records").fetchone()[0]
                fts_count = conn.execute("SELECT COUNT(*) FROM records_fts").fetchone()[0]
                first_id, last_id = conn.execute(
                    "SELECT MIN(source_line), MAX(source_line) FROM records"
                ).fetchone()

                if db_count != total or fts_count != total:
                    raise RuntimeError(
                        f"Verification failed: source={total}, records={db_count}, fts={fts_count}"
                    )

                result = {
                    "db": str(db_path),
                    "source": str(source),
                    "records": total,
                    "fts": fts_count,
                    "first_line": first_id,
                    "last_line": last_id,
                    "avg_chars": total_chars / max(total, 1),
                    "avg_words": total_words / max(total, 1),
                    "sha256": source_hash,
                    "size": size,
                }
                self.progress.emit(100)
                self.status.emit("Build and verification complete.")
                self.finished.emit(result)
            finally:
                conn.close()

        except Exception as e:
            self.failed.emit(f"{type(e).__name__}: {e}")


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("JASS Mizo Corpus Builder v1.0")
        self.resize(1000, 700)
        self.source = None
        self.thread = None
        self.worker = None

        root = QWidget()
        self.setCentralWidget(root)
        layout = QVBoxLayout(root)

        title = QLabel("JASS Mizo Corpus Builder v1.0")
        title.setStyleSheet("font-size:22px;font-weight:700;")
        layout.addWidget(title)

        layout.addWidget(QLabel(
            "Builds a faithful, searchable SQLite database from the Mizo corpus. "
            "The source TXT is read-only and is never modified."
        ))

        source_row = QHBoxLayout()
        self.source_label = QLabel("No source selected")
        self.source_label.setWordWrap(True)
        select = QPushButton("Select Source TXT")
        select.clicked.connect(self.select_source)
        source_row.addWidget(self.source_label, 1)
        source_row.addWidget(select)
        layout.addLayout(source_row)

        output_row = QHBoxLayout()
        self.output_label = QLabel("Output: JASS_Mizo_Corpus.db")
        output_row.addWidget(self.output_label, 1)
        choose_output = QPushButton("Choose Output")
        choose_output.clicked.connect(self.choose_output)
        output_row.addWidget(choose_output)
        layout.addLayout(output_row)

        box = QGroupBox("Build")
        grid = QGridLayout(box)
        self.status = QLabel("Ready")
        self.progress = QProgressBar()
        self.build_btn = QPushButton("Build Database")
        self.build_btn.setEnabled(False)
        self.build_btn.clicked.connect(self.start_build)
        grid.addWidget(self.status, 0, 0, 1, 2)
        grid.addWidget(self.progress, 1, 0, 1, 2)
        grid.addWidget(self.build_btn, 2, 0, 1, 2)
        layout.addWidget(box)

        self.output = QPlainTextEdit()
        self.output.setReadOnly(True)
        layout.addWidget(self.output, 1)

        self.output_path = "JASS_Mizo_Corpus.db"

    def select_source(self):
        fn, _ = QFileDialog.getOpenFileName(
            self, "Select Mizo corpus", "", "Text files (*.txt);;All files (*.*)"
        )
        if fn:
            self.source = fn
            self.source_label.setText(fn)
            self.build_btn.setEnabled(True)

    def choose_output(self):
        fn, _ = QFileDialog.getSaveFileName(
            self, "Choose output database", "JASS_Mizo_Corpus.db",
            "SQLite database (*.db);;All files (*.*)"
        )
        if fn:
            self.output_path = fn
            self.output_label.setText(f"Output: {fn}")

    def start_build(self):
        if not self.source:
            return

        source = Path(self.source)
        output = Path(self.output_path)

        if output.exists():
            QMessageBox.warning(
                self, "Output exists",
                "The selected output database already exists. Choose another filename."
            )
            return

        self.build_btn.setEnabled(False)
        self.progress.setValue(0)
        self.output.clear()

        self.thread = QThread()
        self.worker = BuildWorker()
        self.worker.moveToThread(self.thread)
        self.thread.started.connect(lambda: self.worker.run(str(source), str(output)))
        self.worker.progress.connect(self.progress.setValue)
        self.worker.status.connect(self.status.setText)
        self.worker.finished.connect(self.build_finished)
        self.worker.failed.connect(self.build_failed)
        self.worker.finished.connect(self.thread.quit)
        self.worker.failed.connect(self.thread.quit)
        self.thread.finished.connect(self.thread.deleteLater)
        self.thread.start()

    @Slot(dict)
    def build_finished(self, result):
        text = (
            "JASS MIZO CORPUS BUILD COMPLETE\n"
            "================================\n\n"
            f"Source: {result['source']}\n"
            f"Database: {result['db']}\n"
            f"Records: {result['records']:,}\n"
            f"FTS records: {result['fts']:,}\n"
            f"First source line: {result['first_line']:,}\n"
            f"Last source line: {result['last_line']:,}\n"
            f"Average characters: {result['avg_chars']:.2f}\n"
            f"Average words: {result['avg_words']:.2f}\n\n"
            f"Source SHA-256:\n{result['sha256']}\n\n"
            "Verification: PASSED\n"
            "Source modification: NONE\n"
        )
        self.output.setPlainText(text)
        self.build_btn.setEnabled(True)
        QMessageBox.information(
            self, "Build complete",
            f"JASS_Mizo_Corpus.db created and verified.\n\n{result['records']:,} records imported."
        )

    @Slot(str)
    def build_failed(self, message):
        self.build_btn.setEnabled(True)
        self.status.setText("Build failed.")
        QMessageBox.critical(self, "Build failed", message)


def main():
    app = QApplication(sys.argv)
    w = MainWindow()
    w.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
