# JASS Mizo Corpus Builder v1.0

Standalone PySide6 builder for creating `JASS_Mizo_Corpus.db` from the inspected Mizo 4M text corpus.

## Design

- Source TXT is read-only.
- Every source line becomes one database record.
- Original source line number is preserved.
- Original text is stored without content cleaning.
- Character and word counts are stored.
- SQLite indexes are created.
- SQLite FTS5 full-text search is created.
- Source SHA-256 and import metadata are recorded.
- Existing output databases are never overwritten.
- The database is verified after import.

## Run

```powershell
py -m pip install PySide6
py .\JASS_Mizo_Corpus_Builder_v1.0.py
```

Select:

`mizo_language_corpus_4m.txt`

Recommended output:

`JASS_Mizo_Corpus.db`

## Expected scale

The inspected source contains 4,000,000 non-empty, unique records. Import may take significant time because the builder creates both the main table and an FTS5 search index.

## Important

This version intentionally does not translate, clean, classify, deduplicate, or delete records. Those operations should be separate future layers so the source corpus remains faithfully represented.
